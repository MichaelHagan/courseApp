package com.example.cgpaucc;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class L300 extends Fragment {

    ArrayList<Sem> sem = new ArrayList<>();

    public L300() {
        // Required empty public constructor
    }


    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.sem_list, container, false);

        sem.add(new Sem("First Semester",R.drawable.l300s1));
        sem.add(new Sem("Second Semester",R.drawable.l300s2));

        SemAdapter StAd = new SemAdapter(getActivity(), sem, R.color.category_colors);

        ListView root = (ListView) rootView.findViewById(R.id.rootview);

        root.setAdapter(StAd);

        root.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Sem selectedSem = sem.get(position);
                if(position == 0){
                    Intent Intent = new Intent(getActivity(),SemesterPreview.class);
                    Intent.putExtra("SEM_KEY", 5);
                    startActivity(Intent);
                }
                else {

                    Intent Intent = new Intent(getActivity(),SemesterPreview.class);
                    Intent.putExtra("SEM_KEY", 6);
                    startActivity(Intent);
                }
            }
        });


        return rootView;
    }
}
