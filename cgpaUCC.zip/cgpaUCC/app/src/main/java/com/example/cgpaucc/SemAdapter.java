package com.example.cgpaucc;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class SemAdapter extends ArrayAdapter<Sem> {

    //Resource ID for the background color for this list of Sems
    private int mColorResourceId;
    public SemAdapter(Activity context, ArrayList<Sem> pSem, int colorResourceId){

        super(context,'0', pSem);
        mColorResourceId = colorResourceId;
    }


    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listItemView = convertView;
        if(listItemView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.sem_list_item, parent,false);
        }


        Sem currentSem = getItem(position);

        TextView SemTextView = (TextView) listItemView.findViewById(R.id.Sem_text_view);
        SemTextView.setText(currentSem.getSemesterText());


        ImageView default_Image = (ImageView) listItemView.findViewById(R.id.image);

        if(currentSem.hasImage()) {
            default_Image.setImageResource(currentSem.getImg());
            default_Image.setVisibility(View.VISIBLE);
        }
        else{

            default_Image.setVisibility(View.GONE);

        }

        //Set the theme color for the list item
        View textContainer = listItemView.findViewById(R.id.text_container);
        //Find the color that the resource ID maps to
        int color = ContextCompat.getColor(getContext(),mColorResourceId);
        //Set the background color of the text container View
        textContainer.setBackgroundColor(color);


        return listItemView;
    }
}


